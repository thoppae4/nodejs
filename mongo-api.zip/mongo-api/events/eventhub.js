var events=require('events');
var logger=require("../logger");
var emitter=new eventEmitter();
emitter.on("update",function(data){

})
emitter.on("more",function(data){
    logger.info("Number of employees in"+data+"is update");

});
emitter.on("more",function(data){
    logger.info("For pattern search"+"the number of records excedded 50 and it is"+data);
});
module.exports=emitter;