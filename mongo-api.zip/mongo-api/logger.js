


var logger=require('nodjslogger');
logger.init({"file":_dirname+"/logs/debug.log","mod":"DIE"})
module.exports=logger;
