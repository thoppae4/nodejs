var express = require('express');
var app=express();

var bodyParser=require('body-parser');
var fs = require('fs');

app.use(bodyParser.urlencoded());

app.listen(4500, function(){
    console.log("Server is listening on 4500");
});

app.get('/', function(request, response){
    response.send("Hi!! from express");
});

app.post("/store",function(request,response){
    var sno=request.body.sno;
    var name = request.body.name;
    var city = request.body.city;

    var obj = {sno:sno,name:name,city:city};
    obj = JSON.stringify(obj);
    fs.appendFile("data/info.txt", obj, function(err){
        if(err)
        response.send("Data not stored!!!");
        response.send("Data stored into a file");
    });
});

app.use(express.static(__dirname + '/public/styles'));
app.use(express.static(__dirname + '/public/scripts'));
app.use(express.static(__dirname + '/bower_components'));

app.get('/home', function(request, response){
    response.sendFile(__dirname + "/public/views/index.html");
});
