var x = require('./lib');

var obj=new x.student(12,"Ram");
obj.display();
console.log("This is from the krishna node app");

module.exports.student=x.student; 
