//var os=rewuire('os');
//var fs=reuire('fs');
var obj=require('./mod');
obj.fun();
console.log(obj.names);
/*console.log(os.arch());
console.log(os.platform()); */
