module.exports.fun=function(){
    console.log("Oho...................");
}

module.exports.names=["Ram","Rahim"];