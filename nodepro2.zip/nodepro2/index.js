var http=require('http');
http.createServer(function(request,response){
    console.log("server is running");
        response.write("hi .....node");
    response.end();
}
).listen(4000); 