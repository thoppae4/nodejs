function callThisToo(p)
{
    console.log(p);

    return function(q)
    {
        console.log(q);
    }
} // function returing a function

callThisToo("Broad")("France");