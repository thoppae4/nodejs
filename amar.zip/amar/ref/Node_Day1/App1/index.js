//console.log("First node app");

//alert("Hello from node app");

function fun(a)
{
    //console.log("test");
    return "Hi" + a;
}

function fun(b)
{
    //console.log("test");
    return "Hello" + b;
}

var a = 23;
var b = true;
var c = 'test';
var d = [21, 32.2, 'Rajesh'];

console.log(a+ " " + b + " " + c + " " + d[2]);
/* in JS a function is also an object,
so a variable can also hold a function */

//console.log(fun());

var e = function()
{
console.log ("E function");
}

e();