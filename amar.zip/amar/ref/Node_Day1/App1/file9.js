var obj =["1343", "5khkh", "Ram", "Ravi", "Rajkumar", "Sky", "toy", "week", "shoe", "Roger", "myth@gmail.com","harish@gmail.com","Brett@hotmail.com",
"Christ", "Johan", "John", "jhon", "jon", "Man124", "man.123@gmail.com", "blue@gmail","34er34" ];
//var regex=/^[a-zA-Z][a-zA-Z]{2,4}[a-zA-Z]$/;
//var regex=/^[a-zA-Z].{2,3}[a-zA-Z]$/;
//var regex=/^[Jj](oh|o|ho)[n]$/;
//var regex=/\./;
var regex=/^[a-zA-Z][a-zA-Z0-9_\.]+@[a-z]+[\.][a-z]{2,5}$/;

for(var x in obj)
{
    if(regex.test(obj[x]))
        console.log(obj[x]);
}

/* regular expression is a string pattern which is build by using 
some special characters. Where the characters has some in built meaninig */

/* 
^ - strings beginning with any specified character *
^R - strings beginning with R
^[0-9] strings beginning with 0 to 9
^[Mm] strings beginning with M or m
[abc] strings beginning with a or b or c
$ ending with 
+ one or more occurences
* zero or more occurences
{n} number of occurences
{m,n} minimum & maximum of occurences
. any character
() set of alternate strings
*/

/* A string with begin with alphabet and end with alphabet and middle also alphabets 
Only alphabets */