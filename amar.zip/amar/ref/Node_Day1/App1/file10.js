class Student{
    constructor(sno, sname)
    {
        this.sno = sno;
        this.sname = sname;
    }

    display()
    {
        console.log(this.sno + " " + this.sname);
    }

    display(x)
    {
        console.log("World!!!");
    }
}

var obj = new Student(12, "Naveen");
var obj1 = new Student(13, "Peter");

obj.display();
obj1.display();