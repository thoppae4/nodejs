/* Arrow functions*/
var a = function (){
    return "Hello World!!!";
}

console.log(a());

var b=()=>"Hello World!!!";

console.log(b());

var n=(a)=> "Hello " + a;
console.log(n("Rajesh"));

var test =()=>{
    console.log("Line1");
    console.log("Line2");
}

test();