function Student(sno,sname){
this.sno=sno;
this.name=sname;
}

Student.prototype.display = function(){
    console.log(this.sno + " " + this.name);
    return {chain : function (){
        console.log("This is a function");
    }}
}

var obj = new Student(12,"Ramesh");
obj.display().chain();