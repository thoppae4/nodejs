function callme(p)
{
    console.log("Function line 1");
    p("World","India");
    p("Pakistan","Afganistan");
    console.log("Function line 3");
} // function with function as a parameter

callme(function (a,b)
{
    console.log("this is called back");
    console.log("a value is " + a);
    console.log("b value is " + b);
}); // function call by passing function as a parameter

