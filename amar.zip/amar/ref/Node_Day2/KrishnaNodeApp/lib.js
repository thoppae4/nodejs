class Student 
{
    constructor(sno, sname)
    {
        this.sno=sno;
        this.sname=sname;
    }
    
    display()
    {
        console.log(this.sno + " " + this.sname);
    }
}

module.exports.student=Student;