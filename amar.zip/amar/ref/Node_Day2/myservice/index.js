var http = require('http');

http.createServer(function(request,response){
    console.log("server is running!!!");
    response.write("Hi!!! Node")
    response.end();
}).listen(4000);
