var obj=require("krishnanodeapp");

var temp=new obj.student(23,"Ravi");

temp.display();