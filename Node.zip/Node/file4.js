function callthis(p,q,r){
    q(greet(p));
    r(greet(p));
}
function greet(j){
    return "hello !!"+j;
}
callthis("chis",function(a)
{
    console.log("Hey!!!"+a);
},
function(b)
{
    console.log("Heyyyy!!!"+b);
});