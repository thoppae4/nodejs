function Student(sno,name){
    this.sno=sno;
    this.name=name;
}
Student.prototype.display=function(){
    console.log(this.sno+" "+this.name);
    return{chain:function(){
        console.log("This is a function");
    }}
}
var obj=new Student(12,"AMAr");
var x=obj.display();
x.chain();