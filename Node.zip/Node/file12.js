 var a=20;
 function test()
 {
     var a=30;
     console.log("inside"+a);
     {
         let a=45;
         console.log("within block"+a);
         
        }
 }
 test();
 for(let a=5;a<40;a++)
 {}
 console.log(a);