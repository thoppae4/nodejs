var obj=["1343", "5khkh", "Ram","Ravi","Rjakumar","sky","toy",
"week","shoe","roger","myth@gmail.com","harish@gmail.com","Brett@hotmail.com","christ","Johan","Jhom",
"Jon", "Man124",
"man.123@gmail.com","blue@gmail","34er34" ];

var regex=/^[0-9]/;
for (var x in obj)
{
    if(regex.test(obj[x]))
    console.log(obj[x]);
}
