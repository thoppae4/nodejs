class student{
    constructor(sno,name){
        this.sno=sno;
        this.name=name;

    }
    display()
    {
        console.log(this.sno+ " "+this.name);
    }
    display(x)
     {
        console.log("world!!!!");
    }

    

}
var obj=new student(12,"amar");
var obj1=new student(13,"siva");
obj.display();
obj1.display(); 