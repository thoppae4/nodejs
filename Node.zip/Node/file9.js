var obj=[23,45,"Robert",function(){
    console.log("running ...!!!");
},function(){
    console.log("Walking.....!!!");
 },[12,23,function(){
     console.log("Flying");

 }]]
obj[3]();
obj[4]();
obj[5][2]();
var matrix=[[1,2,3],[1,4,3],[13,34,34]];
console.log(matrix);