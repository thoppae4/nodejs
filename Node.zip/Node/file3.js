function callme(p){
    console.log("function line1");
    p("World","India");
    p("wrold1","india1")
    console.log("function line3");
}
callme(function(a,b){
    console.log("this is called back");
    console.log("a value is:" +a);
    console.log("b value is:"+b);
    
})
//function call by passing function as parameter.