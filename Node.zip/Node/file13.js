/* arrow function*/
var a=function(){
    return "Hello world!!";
}
console.log(a());
var b=()=>"Hellow world!!!";
console.log(b());
var n=(z)=>"Hellow"+z;
console.log(n("Rajesh"));
var test=()=>{
    console.log("line1");
    console.log("line2");
}
test();