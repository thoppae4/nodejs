function callme(p){
    console.log("prcoess");
    p("europe");
}
class Containent{
    constructor(){
        this.value="Asia";
    }
    changeContinent()
    {
        callme((data)=>this.value=data);
    }
    display(){
        console.log(this.value);
    
    }
}