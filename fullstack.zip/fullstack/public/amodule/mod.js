var mod=angular.module('restmod',[]);
mod.controller("rest",['httpservice','$scope',function($scope){
    $scope.pattern="ax";
    $scope.companies = ['abc',"xyz",
    "pqr"];
    $scope.readpattern=function(){
        httpservice.getcompanies($scope.pattern).then(
            (data)=>{
                $scope.companies=data;
                $scope.$digest();
            },
            (error)=>{
                $scope.companies=[];
                $scope.$digest();
            }
        )
        console.log($scope.pattern);
        
          }
}]);

  mod.service('httpservice',['$http',function($http){
      this.getCompanies=function(pattern){
          return new Promise(function(resolve,reject){
              $http.get("http://localhost:4780/mongo-api/cnames/"+pattern).then(
                  (response)=>{resolve(response.data);},
                  (error)=>{reject([]);}
              )

          });
     $http.get("HTTP://localhost:4780/mongo-api.cnames/"+pattern).then(
         (response)=>{return response.data;},
         (error)=>{return[]}
     );
     return [{name:"dummy"}];
 }
}]);