var express = require('express');
var app=express();
//for parsing the incomming request
var bodyParser=require('body-parser');
var dbroutes=require('./routes/dbroutes');
var fs = require('fs');

app.use(bodyParser.urlencoded());
app.use("/dbroutes",dbroutes);

app.listen(4500, function(){
    console.log("Server is listening on 4500");
});


app.set('views',__dirname+'/public/templates');
app.set('view engine','ejs');

app.get('/', function(request, response){
    response.send("Hi!! from express");
});

app.post("/store",function(request,response){
    var sno=request.body.sno;
    var name = request.body.name;
    var city = request.body.city;

    var obj = {sno:sno,name:name,city:city};
   // obj = JSON.stringify(obj);
    fs.readFile("data/info.txt",'utf8',function(err,data)
    {
        if(err)
            response.send("error");
             var temp=JSON.parse(data);
            temp.push(obj);
            temp=JSON.stringify(temp);
            fs.writeFile("data/info.txt", temp, function(err){
            if(err)
                response.send("Data not stored!!!");
                response.send("Data stored into a file");
    });
    
    });
});
/*app.get("/table",function(request,response){
    fs.readFile('data/info.txt','utf8',function(err,data){
        if(err)
        response.send("no data ....!!");
        let info=JSON.parse(data);   
        response.render("table",{data:info});     
    });

});*/




app.use(express.static(__dirname + '/public/styles'));
app.use(express.static(__dirname + '/public/scripts'));
app.use(express.static(__dirname + '/bower_components'));
app.use(express.static(__dirname + '/public/amodule'));
 

app.get('/home', function(request, response){
    response.sendFile(__dirname + "/public/views/index.html");
});
app.get('/restclient', function(request, response){
    response.sendFile(__dirname + "/public/views/angular.html");
});